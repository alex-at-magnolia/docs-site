/**
 * Define properties and methods which can be accessed on the template script.
 * You can use Magnolia rendering context objects content, def, ctx, state, i18n.
 * For further info see https://documentation.magnolia-cms.com/display/DOCS56/JavaScript+Models+module.
 * 
 * @constructor
 */
var __modelName__ = function () {
    
    var System = Java.type("java.lang.System");

    /**
     * Outputs 'Hello, world!' greeting into Tomcat catalina logfile.
     */
    this.greet = function () {
        System.out.println("Hello, world!");
    }

    /**
     * Returns random number.
     */
    this.getRandomNumber = function () {
        return Math.random();
    }
};
    
new __modelName__();
    